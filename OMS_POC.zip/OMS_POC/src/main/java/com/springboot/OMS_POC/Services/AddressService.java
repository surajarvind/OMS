package com.springboot.OMS_POC.Services;

import com.springboot.OMS_POC.Payloads.AddressDto;

public interface AddressService
{
  AddressDto createAdd(AddressDto addressDto);
}
